1. his package contains the source code for the following paper:

@article{zhang2021high,
  title={High-order nonlocal Hashing for unsupervised cross-modal retrieval},
  author={Zhang, Peng-Fei and Luo, Yadan and Huang, Zi and Xu, Xin-Shun and Song, Jingkuan},
  journal={World Wide Web},
  volume={24},
  number={2},
  pages={563--583},
  year={2021},
  publisher={Springer}
}

2. We use MIRFLICKR-25K dataset as a demo, some of configurations are slightly adjusted.

3. run:
 
 3.0. please preprocessing the dataset to appropriate input format or downloading the dataset via pan.baidu.com.
      MIRFLICKR25K:
      link: https://pan.baidu.com/s/1o5jSliFjAezBavyBOiJxew
      password: 8dub
 
 3.1. put files in ./Datasets and confirm if the path in ./utils/datasets_mir is correct before loading datasets. 
 
 3.2 run mir_main.py


 