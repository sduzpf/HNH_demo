import torch
import math
import torchvision
import torch.nn as nn
import torch.nn.functional as F


class ImgNet(nn.Module):
    def __init__(self, code_len):
        super(ImgNet, self).__init__()
        self.alexnet = torchvision.models.alexnet(pretrained=True)
        self.alexnet.classifier = nn.Sequential(*list(self.alexnet.classifier.children())[:6])
        self.fc_encode = nn.Linear(4096, code_len)
        self.alpha = 1.0

    def forward(self, x):
        x = self.alexnet.features(x)
        x = x.view(x.size(0), -1)
        feat = self.alexnet.classifier(x)
        hid = self.fc_encode(feat)
        code = torch.tanh(self.alpha * hid)

        return feat, hid, code

    def set_alpha(self, epoch):
        self.alpha  = math.pow((1.0 * epoch + 1.0), 0.5)

class GCNLI(nn.Module):
    def __init__(self, code_len):
        super(GCNLI, self).__init__()

        self.gconv1 = nn.Linear(4096, 2048)
        self.BN1 = nn.BatchNorm1d(2048)
        self.act1 = nn.ReLU()

        self.gconv2 = nn.Linear(2048, 2048)
        self.BN2 = nn.BatchNorm1d(2048)
        self.act2 = nn.ReLU()

        self.gconv3 = nn.Linear(2048, code_len)
        self.alpha = 1.0

    def forward(self, x, in_affnty, out_affnty):
        out = self.gconv1(x)
        out = in_affnty.mm(out)
        out = self.BN1(out)
        out = self.act1(out)

        # block 2
        out = self.gconv2(out)
        out = out_affnty.mm(out)
        out = self.BN2(out)
        out = self.act2(out)

        # block 3
        out = self.gconv3(out)
        out = torch.tanh(self.alpha * out)

        return out

    def set_alpha(self, epoch):
        self.alpha  = math.pow((1.0 * epoch + 1.0), 0.5)


class GCNLT(nn.Module):
    def __init__(self, code_len):
        super(GCNLT, self).__init__()

        self.gconv1 = nn.Linear(4096, 2048)
        self.BN1 = nn.BatchNorm1d(2048)
        self.act1 = nn.ReLU()

        self.gconv2 = nn.Linear(2048, 2048)
        self.BN2 = nn.BatchNorm1d(2048)
        self.act2 = nn.ReLU()

        self.gconv3 = nn.Linear(2048, code_len)
        self.alpha = 1.0

    def forward(self, x, in_affnty, out_affnty):
        out = self.gconv1(x)
        out = in_affnty.mm(out)
        out = self.BN1(out)
        out = self.act1(out)

        # block 2
        out = self.gconv2(out)
        out = out_affnty.mm(out)
        out = self.BN2(out)
        out = self.act2(out)

        # block 3
        out = self.gconv3(out)
        out = torch.tanh(self.alpha * out)

        return out

    def set_alpha(self, epoch):
        self.alpha  = math.pow((1.0 * epoch + 1.0), 0.5)

class TxtNet(nn.Module):
    def __init__(self, code_len, txt_feat_len):
        super(TxtNet, self).__init__()
        self.fc1 = nn.Linear(txt_feat_len, 4096)
        self.fc2 = nn.Linear(4096, 4096)
        self.fc3 = nn.Linear(4096, code_len)
        self.alpha = 1.0

    def forward(self, x):
        feat = self.fc1(x)
        feat = F.relu(self.fc2(feat))
        # feat = F.relu(self.fc1(x))
        #         # feat = F.relu(self.fc2(feat))

        hid = self.fc3(feat)
        code = torch.tanh(self.alpha * hid)
        return feat, hid, code

    def set_alpha(self, epoch):
        self.alpha  = math.pow((1.0 * epoch + 1.0), 0.5)


class JNet(nn.Module):
    def __init__(self, code_len):
        super(JNet, self).__init__()
        self.fc_encode = nn.Linear(8192, code_len)
        self.alpha = 1.0

    def forward(self, x):
        hid = self.fc_encode(x)
        code = torch.tanh(self.alpha * hid)

        return hid, code

    def set_alpha(self, epoch):
        self.alpha  = math.pow((1.0 * epoch + 1.0), 0.5)